﻿using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace пр13_14.Converters
{
    public class NullToVisibilityConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool hasImage = value != null &&
                           ((value is byte[] bytes && bytes.Length > 0) ||
                            (value is System.Windows.Media.Imaging.BitmapImage bitmap && bitmap.UriSource != null));

            return hasImage ? Visibility.Collapsed : Visibility.Visible;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}