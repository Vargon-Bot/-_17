﻿using System.Windows;
using пр13_14.Pages;

namespace пр13_14
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            if (!DatabaseHelper.TestConnection())
            {
                MessageBox.Show("Нет соединения с базой данных! Проверьте настройки.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            MainFrame.Navigate(new LoginPage());
        }
    }
}