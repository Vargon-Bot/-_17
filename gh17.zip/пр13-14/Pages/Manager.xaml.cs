﻿using System.Windows;
using System.Windows.Controls;

namespace пр13_14.Pages
{
    public partial class Manager : Page
    {
        public Manager()
        {
            InitializeComponent();
        }

        
    }
}