﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace пр13_14.Pages
{
    public partial class CatalogPage : Page
    {
        private List<EventCardData> _allEvents; 
        private ICollectionView _collectionView; 

        public CatalogPage()
        {
            InitializeComponent();
            LoadEvents();
        }

        private void LoadEvents()
        {
            try
            {
                _allEvents = DatabaseHelper.GetAllEvents();

                _collectionView = CollectionViewSource.GetDefaultView(_allEvents);

                _collectionView.Filter = FilterPredicate;

                ApplySorting();

                lvEvents.ItemsSource = _collectionView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }


        private bool FilterPredicate(object obj)
        {
            EventCardData item = obj as EventCardData;
            if (item == null) return false;

            string searchText = tbSearch.Text.ToLower();
            if (!string.IsNullOrEmpty(searchText))
            {
                if (!item.EventName.ToLower().Contains(searchText) &&
                    !item.Description.ToLower().Contains(searchText))
                    return false;
            }

            ComboBoxItem statusItem = cbFilterStatus.SelectedItem as ComboBoxItem;
            string statusFilter = statusItem?.Content.ToString();
            if (statusFilter != "Все статусы")
            {
                if (item.Status != statusFilter) return false;
            }

            ComboBoxItem typeItem = cbFilterType.SelectedItem as ComboBoxItem;
            string typeFilter = typeItem?.Content.ToString();
            if (typeFilter != "Все типы")
            {
                if (item.EventType != typeFilter) return false;
            }

            return true;
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            _collectionView.Refresh();
        }

        private void Filter_Changed(object sender, SelectionChangedEventArgs e)
        {
            _collectionView.Refresh();
        }

        private void ApplySorting()
        {
            _collectionView.SortDescriptions.Clear();

            ComboBoxItem item = cbSort.SelectedItem as ComboBoxItem;
            string tag = item?.Tag?.ToString();

            switch (tag)
            {
                case "DateDesc":
                    _collectionView.SortDescriptions.Add(new System.ComponentModel.SortDescription("EventDate", System.ComponentModel.ListSortDirection.Descending));
                    break;
                case "DateAsc":
                    _collectionView.SortDescriptions.Add(new System.ComponentModel.SortDescription("EventDate", System.ComponentModel.ListSortDirection.Ascending));
                    break;
                case "NameAsc":
                    _collectionView.SortDescriptions.Add(new System.ComponentModel.SortDescription("EventName", System.ComponentModel.ListSortDirection.Ascending));
                    break;
                case "NameDesc":
                    _collectionView.SortDescriptions.Add(new System.ComponentModel.SortDescription("EventName", System.ComponentModel.ListSortDirection.Descending));
                    break;
                case "BudgetDesc":
                    _collectionView.SortDescriptions.Add(new System.ComponentModel.SortDescription("TotalBudget", System.ComponentModel.ListSortDirection.Descending));
                    break;
            }
        }

        private void Sort_Changed(object sender, SelectionChangedEventArgs e)
        {
            ApplySorting();
        }

        private void LvEvents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = lvEvents.SelectedItem != null;
            btnEdit.IsEnabled = isSelected;
            btnDelete.IsEnabled = isSelected;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (lvEvents.SelectedItem is EventCardData selected)
            {
                if (Application.Current.MainWindow is MainWindow mainWindow)
                    mainWindow.MainFrame?.Navigate(new AddEditPage(selected));
            }
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (lvEvents.SelectedItem is EventCardData selected)
            {
                if (Application.Current.MainWindow is MainWindow mainWindow)
                    mainWindow.MainFrame?.Navigate(new AddEditPage(selected));
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (lvEvents.SelectedItem is EventCardData selected)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить '{selected.EventName}'?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    if (DatabaseHelper.DeleteEvent(selected.EventID))
                    {
                        LoadEvents();
                        MessageBox.Show("Удалено успешно.");
                    }
                }
            }
        }
    }
}