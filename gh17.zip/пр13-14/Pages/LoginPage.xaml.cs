﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace пр13_14.Pages
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = tbLogin.Text;
            string pass = pbPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            int? roleId = DatabaseHelper.ValidateUser(login, pass);

            if (roleId.HasValue)
            {
                if (Application.Current.MainWindow is MainWindow mw)
                    mw.MainFrame.Navigate(new CatalogPage());
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }

        private void GoToRegister_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
                mw.MainFrame.Navigate(new RegistrationPage());
        }
    }
}